#ifndef _POINTER_H
#define _POINTER_H

void grab_pointer(pointer_action_t);
void track_pointer(int, int);

#endif
