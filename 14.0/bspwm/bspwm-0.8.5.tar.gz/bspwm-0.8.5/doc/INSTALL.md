# Dependencies

- libxcb
- xcb-util
- xcb-util-wm

# Installation

    make && make install

# Removal

    make uninstall

# Packages

- Arch Linux
    - [bspwm-git](https://aur.archlinux.org/packages/bspwm-git)
    - [bspwm](https://aur.archlinux.org/packages/bspwm)

- Gentoo Linux
    - [bspwm-git](https://github.com/milomouse/ebuilds)
