#ifndef _RESTORE_H
#define _RESTORE_H

void restore_tree(char *);
void restore_history(char *);
void restore_stack(char *);

#endif
