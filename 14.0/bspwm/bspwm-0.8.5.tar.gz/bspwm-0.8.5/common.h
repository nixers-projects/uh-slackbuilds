#ifndef _COMMON_H
#define _COMMON_H

#define DEFAULT_SOCKET_PATH  "/tmp/bspwm-socket"
#define SOCKET_ENV_VAR       "BSPWM_SOCKET"
#define MESSAGE_FAILURE      '\x18'

#endif
