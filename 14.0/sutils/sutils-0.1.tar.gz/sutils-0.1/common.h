#ifndef _COMMON_H
#define _COMMON_H

#define MAXLEN        256

#endif
